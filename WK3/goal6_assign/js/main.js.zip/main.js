/*
	* Goal 6 Assignment for PWA-1
*/

//Self execution
(function() {

//Array of students
    var students = [

    {
        uname: 'John Doe',
        Address: {Street: '123 Boring DR.', City: 'Somewhere', State: 'ID'},
        GPA: [10, 15, 20, 25]
    },

    {
        uname: 'Karen Doe',
        Address: {Street: '123 Snooze Dr.', City: 'Donut', State: 'NM'},
        GPA: [5, 10, 20, 15]
    },

    {
        uname: 'Phillip Doe',
        Address: {Street: '123 Blech Dr.', City: 'Bored', State: 'OK'},
        GPA: [5, 10, 2, 5]
    },

    {
        uname: 'Stephen Doe',
        Address: {Street: '123 Ugh Dr.', City: 'Hotlanta', State: 'GA'},
        GPA: [5, 7, 20, 1]
    }];

//Logging Student Info
    var consoleData = function () {
        for (var i = 0, j = students.length; i < j; i++) {
            console.log('Name: ' + students[i].uname);
            console.log('Address; ' + students[i].address.street + ' ' + students[0].address.city + ' ' + students[0].address.state);
            console.log('GPA: ' + students[i].gpa);
            console.log('Date: '
                    + students[i].date.getMonth() + "/"
                    + students[i].date.getDate() + "/"
                    + students[i].date.getFullYear()
            );
        }
        ;
        return false;
    };

//Dynamically add students
    var addData = function (newname, newstreet, newcity, newstate, newgpa, newdate) {

        //Using .push method to add new students
        students.push({
            uname: newname,
            address: {street: newstreet, city: newcity, state: newstate},
            gpa: newgpa,
            date: newdate
        });
    };

//GPA "Average" Calculation
    var gpaAvg = function (myArray) {

//console.log(myArray.length);

        //console.log(myArray.length);
        var gradeAvg = 0;
        for (var i = 0, max = myArray.length; i < max; i++) {
            gradeAvg = gradeAvg + myArray[i];
        }
        ;

        var num = gradeAvg / max;
        return num.toFixed(2);
    };

//Displays HTML of student info
    var displayData = function () {

        //DOM elements for HTML
        var innerName = document.getElementById("name");
        var innerAddress = document.getElementById("address");
        var innerGpa = document.getElementById("gpa");
        var innerDate = document.getElementById("date");
        var innerAvgGpa = document.getElementById("avggpa");

//Not equal, display another student
        if (i !== max + 1) {
            innerName.InnerHTML = 'Name: ' + students[i].uname;
            innerAddress.InnerHTML = 'Address: ' + students[i].address.street + ' ' + students[i].address.city + ' ' + students[i].address.state;
            innerGpa.innerHTML = 'GPA: ' + students[i].gpa;

            //Used after everything else is displayed
            innderDate.innerHTML = 'Date: '
                + students[i].date.getMonth() + "/"
                + students[i].date.getDate() + "/"
                + students[i].date.getFullYear();

            //console.log(students[i].gpa)
            var avg = gpaAvg(students[i].gpa);

            innerAvgGpa.innerHTML = 'Average GPA: ' + avg;
            console.log(students[i].gpa.length)

//Changes btn txt to DONE
        } else {
            button.onclick = "return false";
            document.getElementById('.buttonred').innerHTML = 'DONE!';
        }
        ;
        i++
        return false;
    };

    var max = students.length;

//Click event
    button.onClick = displayData;

//Console.log original & new objects
    console.log('*************Original Objects************')
    consoleData();
    addData('Wonder Woman', '123 Test Dr', 'Orlando', 'Florida', [3.2, 4.0, 2.2], new Date());
    console.log(' ');
    console.log('*************New Objects************')
    consoleData();
    displayData();

})(); //THE END
